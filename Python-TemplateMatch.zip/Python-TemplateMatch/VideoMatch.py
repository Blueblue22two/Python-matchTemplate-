import cv2 as cv
import numpy as np
import math

"""对视频进行模板匹配算法"""
def match(source, template, nums):
    """
    1.将每一次计算出的R值放入矩阵mart
    2.计算完毕后，在mart中寻找R值最大的数并获取其在矩阵中的位置（获取的位置为初始点）
    3.对原图中匹配的位置绘制出来
    """
    """图像转化为灰度图"""
    s = cv.cvtColor(source, cv.COLOR_BGRA2GRAY)
    t = cv.cvtColor(template, cv.COLOR_BGRA2GRAY)
    wt,ht= t.shape[::-1]  # wt = t.shpe[1], ht = t.shape[0]
    '''图片向下采样i次减少计算量'''
    for i in range(nums):
        imgS = cv.pyrDown(s)
        temps = imgS
        imgT = cv.pyrDown(t)
        tempt = imgT
        s = temps
        t = tempt
    """获取图像的尺寸 w(x), h(y)"""
    w, h = imgS.shape[::-1]
    w1, h1 = imgT.shape[::-1]
    print("imgS图像尺寸 height(y):width(x)", h, w)
    print("imgT图像尺寸 height(y):width(x)", h1, w1)
    """创建空矩阵并指定其数据类型"""
    mart = np.zeros(shape=(h - h1, w - w1), dtype=np.float32)
    """计算"""
    sum_t = calculate_sum_pow(imgT)
    for x in range(w - w1):
        for y in range(h - h1):
            mart[y, x] = calculate(imgS, imgT, x, y, w1, h1, sum_t)
    "计算完毕"
    max_loc = cv.minMaxLoc(mart)[3]
    # 计算出缩小的倍数times, 将结果矩阵mart中返回的最大值的点乘以times，再从source原图中绘出模板位置
    times = math.pow(2, nums)
    max_pos = (int(max_loc[0] * times), int(max_loc[1] * times))
    # "绘制框选位置"
    result = cv.rectangle(source, max_pos, (max_pos[0] + wt, max_pos[1] + ht), (0, 255, 0), 3)
    cv.imshow("video", source)  # 显示返回的每帧
    cv.waitKey(35)


def calculate_sum_pow(image):
    """将计算公式分母部分中的math.sqrt(math.pow(sum_t,2))计算出来方便后面重复使用"""
    width, height = image.shape[::-1]
    sum_t = 0
    for wi in range(width):
        for hi in range(height):
            sum_t += math.pow(image[hi, wi], 2)
    return math.sqrt(sum_t)


def calculate(source, template, i, j, width_t, height_t, total_t):
    """计算R值"""
    xt = 0  # 指针xt
    yt = 0  # 指针yt
    val = 0  # 分子部分的总和
    total_s = 0  # 分母部分S的总和
    '''遍历区域中的每个像素点'''
    for numX in range(i, i + width_t):
        if xt < width_t:
            if yt < height_t:
                for numY in range(j, j + height_t):
                    val += (int(source[numY, numX]) * int(template[yt, xt]))
                    total_s += math.pow(source[numY, numX], 2)
                    yt += 1
            else:
                yt = 0
            xt += 1
    return val / (math.sqrt(total_s) * total_t)


def readvideo(video, template):
    cv.namedWindow("video",0)
    cv.resizeWindow("video",1280,800)
    while vid.isOpened():
        # 一帧一帧捕捉
        ret, frame = video.read()
        match(frame, template, 7)


"""主程序"""
img = cv.imread(r"TestImage\Dieji.png")  # 读取图像
vid = cv.VideoCapture(r"TestImage\TestVideo.mp4")  # 读取视频
readvideo(vid,img)
vid.release()
cv.destroyWindow()